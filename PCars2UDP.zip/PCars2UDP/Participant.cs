﻿namespace PCars2UDP
{
    using System;
    using System.Collections;

    /// <summary>
    /// Represents a race participant's data.
    /// </summary>
    [Serializable]
    public class Participant
    {
        private byte racePosition;

        /// <summary>
        /// Gets the Position of the participant's car in the world represented by a 3d point.
        /// </summary>
        public Point3D WorldPosition { get; set; } = new Point3D();

        /// <summary>
        /// Gets the quantized heading for the participant (-PI .. +PI).
        /// </summary>
        public short OrientationHeading { get; set; }

        /// <summary>
        /// Gets the quantized pitch for the participant (-PI / 2 .. +PI / 2).
        /// </summary>
        public short OrientationPitch { get; set; }

        /// <summary>
        /// Gets the quantized bank for the participant (-PI .. +PI).
        /// </summary>
        public short OrientationBank { get; set; }

        /// <summary>
        /// Gets the current lap's distance done by the participant.
        /// TODO: Get unit of mesurement.
        /// Units: Meters ?? - what is it really?
        /// Unset: 0 .
        /// </summary>
        public ushort LapDistance { get; set; }

        /// <summary>
        /// Gets a value indicating whether or not the participant is active.
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets the position of the participant in the race.
        /// Unset = 0 .
        /// </summary>
        public byte RacePosition
        {
            get
            {
                return racePosition;
            }
            set
            {
                // Gets the top bit to check if the race is active
                IsActive = (value & (1 << 7)) != 0;
                // Clear the top bit and to get race position
                racePosition &= byte.MaxValue ^ (1 << 7);
            }
        }

        /// <summary>
        /// Gets the sector that the participant is in.
        /// </summary>
        public int Sector { get; set; }

        /// <summary>
        /// TODO.
        /// </summary>
        public byte HighestFlag { get; set; }
        
        public byte PitModeSchedule { get; set; }
        public UInt16 CarIndex { get; set; }
        public byte RaceState { get; set; }
        public byte CurrentLap { get; set; }
        public Single CurrentTime { get; set; }
        public Single CurrentSectorTime { get; set; }
    }
}
